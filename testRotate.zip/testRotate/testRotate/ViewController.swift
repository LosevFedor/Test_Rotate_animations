//
//  ViewController.swift
//  testRotate
//
//  Created by Fedor Losev on 27.05.2022.
//

import UIKit

class ViewController: UIViewController {
    lazy var generalView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var view1: UIView = {
       let view = UIView()
        view.backgroundColor = .green
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var view2: UIView = {
       let view = UIView()
        view.backgroundColor = .red
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var labelForView1: UILabel = {
       let label = UILabel()
        label.text = "Label view ONE"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var labelForView2: UILabel = {
       let label = UILabel()
        label.text = "Label view TWO"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var rotateBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("Rotate", for: .normal)
        btn.setTitleColor(UIColor.white, for: .normal)
        btn.backgroundColor = .red
        btn.layer.contents = 14
        btn.addTarget(self, action: #selector(showFlipView), for: .touchUpInside)
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    var isRotate = false
    
    var view1Height: NSLayoutConstraint?
    var view2Height: NSLayoutConstraint?
    
    var label1Height: NSLayoutConstraint?
    var label2Height: NSLayoutConstraint?
    
    var generalViewHeight: NSLayoutConstraint?
    
    func setConstraints() {
        setConstraintForGeneralView()
        setConstrintForView1()
        setConstrintForView2()
        
        setConstrintForLabel1()
        setConstrintForLabel2()
        setConstrintsForBtnRotate()
    }
    
    func setConstrintsForBtnRotate() {
        rotateBtn.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 16).isActive = true
        rotateBtn.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -16).isActive = true
        rotateBtn.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        rotateBtn.heightAnchor.constraint(equalToConstant: 56).isActive = true
    }
    
    @objc func showFlipView() {
        if isRotate {
            isRotate = false
            UIView.transition(with: generalView, duration: 1, options: .transitionFlipFromRight) {
                self.updateConstrints(isRotate: false)
            }
        } else {
            isRotate = true
            UIView.transition(with: generalView, duration: 1, options: .transitionFlipFromLeft) {
                self.updateConstrints(isRotate: true)
            }
        }
    }
    
   
    func setConstraintForGeneralView() {
        generalViewHeight = generalView.heightAnchor.constraint(equalToConstant: 300)
        generalViewHeight?.isActive = true
        generalView.widthAnchor.constraint(equalToConstant: 250).isActive = true
        generalView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0).isActive = true
        generalView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0).isActive = true
    }
    
    func setConstrintForLabel1() {
        label1Height = labelForView1.heightAnchor.constraint(equalToConstant: 20)
        label1Height?.isActive = true
        labelForView1.centerXAnchor.constraint(equalTo: view1.centerXAnchor, constant: 0).isActive = true
        labelForView1.centerYAnchor.constraint(equalTo: view1.centerYAnchor, constant: 0).isActive = true
        labelForView1.widthAnchor.constraint(equalToConstant: 200).isActive = true
    }
    
    func setConstrintForLabel2() {
        label2Height = labelForView2.heightAnchor.constraint(equalToConstant: 0)
        label2Height?.isActive = true
        labelForView2.centerXAnchor.constraint(equalTo: view2.centerXAnchor, constant: 0).isActive = true
        labelForView2.centerYAnchor.constraint(equalTo: view2.centerYAnchor, constant: 0).isActive = true
        labelForView2.widthAnchor.constraint(equalToConstant: 200).isActive = true
    }
    
    func setConstrintForView1() {
        view1.centerXAnchor.constraint(equalTo: generalView.centerXAnchor, constant: 0).isActive = true
        view1.centerYAnchor.constraint(equalTo: generalView.centerYAnchor, constant: 0).isActive = true
        view1Height = view1.heightAnchor.constraint(equalToConstant: 300)
        view1Height?.isActive = true
        view1.widthAnchor.constraint(equalToConstant: 250).isActive = true
    }
    
    func setConstrintForView2() {
        view2.centerXAnchor.constraint(equalTo: generalView.centerXAnchor, constant: 0).isActive = true
        view2.centerYAnchor.constraint(equalTo: generalView.centerYAnchor, constant: 0).isActive = true
        view2Height = view2.heightAnchor.constraint(equalToConstant: 0)
        view2Height?.isActive = true
        view2.widthAnchor.constraint(equalToConstant: 250).isActive = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(generalView)
        generalView.addSubview(view1)
        generalView.addSubview(view2)
        view1.addSubview(labelForView1)
        view2.addSubview(labelForView2)
        view.addSubview(rotateBtn)
        
        setConstraints()
    }
    
    func updateConstrints(isRotate: Bool) {
        if isRotate {
            UIView.animate(withDuration: 0.8, delay: 0.8, animations: { () -> Void in
            }) { finished in
                UIView.animate(withDuration: 1, delay: 0.1, animations: {
                    
                    self.generalView.transform = CGAffineTransform.identity
                    self.generalViewHeight?.constant = 600
                    self.view2Height?.constant = 600
                    self.label2Height?.constant = 20
                    self.label1Height?.constant = 0
                    self.view1Height?.constant = 0// undo in 1 seconds
                    self.view.layoutIfNeeded()
                   })
            }
            
        } else {
            UIView.animate(withDuration: 0.5, animations: { () -> Void in
            }) { f in
                UIView.animate(withDuration: 0.5, animations: {
                    self.generalView.transform = CGAffineTransform.identity
                    self.generalViewHeight?.constant = 300
                    self.label1Height?.constant = 20
                    self.label2Height?.constant = 0
                    self.view2Height?.constant = 0
                    self.view1Height?.constant = 300
                    self.view.layoutIfNeeded()
                })
            }
        }
        
        
    }

}
